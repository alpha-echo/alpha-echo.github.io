Sorting the entry of the log file by days and create one sheet for every days.
Adding some graphics for every days with percentage of appearing method and a main graphic for the evolution of occurences over the days.

Exit code:
0: Normal execution a the programm
1: A Windows has been close by force
2: The User cancel the operation
3: The mail mail was not send to one or more recipients
4: The mail was not send at all
