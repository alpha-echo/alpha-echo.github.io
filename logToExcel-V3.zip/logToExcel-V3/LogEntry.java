/*
 * File: LogEntry.java
 * Description: Class representing an entry log (LogEntry)
 * Author: Alpha_Echo
 */

package logToExcel;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class LogEntry {

	private String msg;
	private String severity;
	private String host;
	private Date date;
	private String method;
	private String line;
	private String file;

	/**
	 * Constructor of LogEntry
	 * 
	 * @param msg        Message of entry log
	 * @param severity   Severity of entry log
	 * @param occurenceI Occurrence of informations
	 * @param occurenceW Occurrence of warnings
	 * @param occurenceE Occurrence of errors
	 * @param host       Host of the entry log
	 * @param date       date of the entry log
	 */

	public LogEntry(String msg, String severity, String host, String date, String method, String line, String file) {
		this.msg = msg;
		this.severity = severity;
		this.host = host;
		SimpleDateFormat nDate = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
		try {
			this.date = nDate.parse(date);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		this.method = method;
		this.line = line;
		this.file = file;
	}

	// Getters

	public String getMsg() {
		return msg;
	}

	public String getSeverity() {
		return severity;
	}

	public String getHost() {
		return host;
	}

	public Date getDate() {
		return date;
	}

	public String getMethod() {
		return method;
	}

	public String getLine() {
		return line;
	}

	public String getFile() {
		return file;
	}

}