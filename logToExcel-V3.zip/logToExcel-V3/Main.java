/*
 * File: Main.java
 * Description: Main class to test log conversion into Excel file
 * Author: Alpha_Echo
 */

package logToExcel;

import java.awt.Color;
import java.awt.Desktop;
import java.awt.Dimension;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Path;
import java.text.SimpleDateFormat;

import javax.swing.BorderFactory;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SpringLayout;
import javax.swing.filechooser.FileNameExtensionFilter;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Main {

	public static void main(String[] args) throws IOException {

		// Select log file
		JFileChooser fileChooser = new JFileChooser();
		fileChooser.setMultiSelectionEnabled(true);
		fileChooser.setDialogTitle("Select log file");
		fileChooser.setFileFilter(new FileNameExtensionFilter("Log file:", "log", "out"));

		int userSelection = fileChooser.showOpenDialog(null);
		if (userSelection == JFileChooser.APPROVE_OPTION) {

			String path = fileChooser.getSelectedFile().getAbsolutePath();
			List<LogEntry> logs = new ArrayList<>();

			try (FileReader fileReader = new FileReader(path); BufferedReader reader = new BufferedReader(fileReader)) {
				String line = reader.readLine();

				// Read line of log and add it to LogEntry
				while (line != null) {

					if (line.startsWith("{")) {

						String host = extractFromLog(line, "host");
						String date = extractFromLog(line, "@timestamp");
						String method = extractFromLog(line, "method");
						String msg = extractFromLog(line, "message");
						String crit = extractFromLog(line, "level");
						String lne = extractFromLog(line, "line_number");
						String file = extractFromLog(line, "file");

						logs.add(new LogEntry(msg, crit, host, date, method, lne, file));

					}
					line = reader.readLine();
				}

			} catch (IOException e) {
				e.printStackTrace();
			}

			// Sort logs by date
			logs.sort(Comparator.comparing(LogEntry::getDate));

			// Group logs by day
			List<List<LogEntry>> logsByDay = groupLogsByDay(logs);

			// Generate Excel file and ask if it should be sent by mail
			String filePath = "logToExcel.xlsx";
			int reponse = JOptionPane.showConfirmDialog(null, "Send file by email?", null, JOptionPane.YES_NO_OPTION);
			if (reponse == 0) {
				Excel.createExcelFile(logsByDay, filePath, false);
				List<String> recipients = new ArrayList<String>();
				List<String> username = new ArrayList<String>();
				List<String> password = new ArrayList<String>();
				askCredentials(recipients, username, password, path);
				SendMail.sendMail(path, recipients, username.get(0), password.get(0));
			} else if (reponse == 1) {
				Excel.createExcelFile(logsByDay, filePath, true);
				showFileCreatedDialog(filePath);
			} else {
				System.exit(1); // Exit if window close
			}
		} else if (userSelection == JFileChooser.CANCEL_OPTION) {
			System.exit(2); // Exit if user cancel
		} else {
			System.exit(1); // Exit if window close
		}

	}

	/**
	 * Extract a part of a line log and return it
	 * 
	 * @param line      Line of log
	 * @param separator Separator from when to start extracting
	 * @param count     Number of characters after the separator
	 * @return The line of log with only the information wanted or a space character
	 */
	private static String extractFromLog(String line, String separator) {

		String reg = separator + "\":\"" + "(.*?)\"";
		Pattern p = Pattern.compile(reg);
		Matcher m = p.matcher(line);
		if (m.find()) {
			line = m.group(0);
			line = line.substring(separator.length() + 3, line.length() - 1);
			return line;
		} else {
			return " ";
		}

	}

	/**
	 * Divide a list of LogEntry into several smaller list regroup by date and add
	 * them to a list of list of LogEntry
	 * 
	 * @param logs The main list to divide
	 * @return The list of list
	 */
	private static List<List<LogEntry>> groupLogsByDay(List<LogEntry> logs) {
		List<List<LogEntry>> logsByDay = new ArrayList<>();
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

		Date currentDate = null;
		List<LogEntry> currentDayLogs = new ArrayList<>();

		for (LogEntry logEntry : logs) {
			Date logDate = logEntry.getDate();

			if (currentDate == null) {
				currentDate = logDate;
			} else if (!dateFormat.format(currentDate).equals(dateFormat.format(logDate))) {
				logsByDay.add(currentDayLogs);
				currentDayLogs = new ArrayList<>();
				currentDate = logDate;
			}

			currentDayLogs.add(logEntry);

		}
		// Add the logs of the last day
		if (!currentDayLogs.isEmpty()) {
			logsByDay.add(currentDayLogs);
		}

		return logsByDay;
	}

	/**
	 * Show a message dialogue informing of the creation of the Excel file and
	 * opening it if desktop environment supported
	 * 
	 * @param path Path of the Excel file to create
	 */
	private static void showFileCreatedDialog(String path) {
		Path file = FileSystems.getDefault().getPath(path);
		String msg = "File " + file.getFileName() + " created";
		JOptionPane.showMessageDialog(null, msg);

		// Open File if Desktop supported
		if (Desktop.isDesktopSupported()) {
			Desktop desktop = Desktop.getDesktop();
			try {
				desktop.open(new File(path));
			} catch (IOException e) {
				e.printStackTrace();
			}
			System.exit(0); // Exit the program
		}

	}

	/**
	 * Display a window with 2 text filed and a password field and ask if more
	 * recipients should be added to the recipients list
	 * 
	 * @param recipients List of recipients for the mailing
	 * @param username   List of username for sending mail (a simple string didn't
	 *                   work)
	 * @param password   List of password for sending mail (a simple string didn't
	 *                   work)
	 * @param path       Path of the Excel file for the case the user make a mistake
	 */
	private static void askCredentials(List<String> recipients, List<String> username, List<String> password,
			String path) {

		// Create a JFrame for creating a JPanel with a SpringLayout
		JFrame frame = new JFrame();
		final SpringLayout layout = new SpringLayout();
		final JPanel panel = new JPanel(layout);
		panel.setPreferredSize(new Dimension(400, 100));

		// Creating label and textField
		JLabel lbl1 = new JLabel("Recipient:");
		JTextField textField1 = new JTextField(23);
		JLabel lbl2 = new JLabel("Your Username:");
		JTextField textField2 = new JTextField(23);
		JLabel lbl3 = new JLabel("Your Password:");
		JPasswordField passwordField = new JPasswordField(23);

		// Adding everything to the panel
		panel.add(lbl1);
		panel.add(textField1);
		panel.add(lbl2);
		panel.add(textField2);
		panel.add(lbl3);
		panel.add(passwordField);

		// Setting constraints for the layout
		layout.putConstraint(SpringLayout.WEST, lbl1, 10, SpringLayout.WEST, panel);
		layout.putConstraint(SpringLayout.NORTH, lbl1, 10, SpringLayout.NORTH, panel);
		layout.putConstraint(SpringLayout.WEST, textField1, 52, SpringLayout.EAST, lbl1);
		layout.putConstraint(SpringLayout.NORTH, textField1, 10, SpringLayout.NORTH, panel);
		layout.putConstraint(SpringLayout.WEST, lbl2, 10, SpringLayout.WEST, panel);
		layout.putConstraint(SpringLayout.NORTH, lbl2, 10, SpringLayout.SOUTH, textField1);
		layout.putConstraint(SpringLayout.WEST, textField2, 10, SpringLayout.EAST, lbl2);
		layout.putConstraint(SpringLayout.NORTH, textField2, 10, SpringLayout.SOUTH, textField1);
		layout.putConstraint(SpringLayout.WEST, lbl3, 10, SpringLayout.WEST, panel);
		layout.putConstraint(SpringLayout.NORTH, lbl3, 10, SpringLayout.SOUTH, textField2);
		layout.putConstraint(SpringLayout.WEST, passwordField, 12, SpringLayout.EAST, lbl3);
		layout.putConstraint(SpringLayout.NORTH, passwordField, 10, SpringLayout.SOUTH, textField2);

		// Adding what's inside fields to lists
		int result = JOptionPane.showConfirmDialog(frame, panel, "Enter required informations",
				JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
		if (result == JOptionPane.YES_OPTION) {
			recipients.add(textField1.getText());
			username.add(textField2.getText());
			password.add(new String(passwordField.getPassword()));

			// JPanel to know if more recipients should be added
			int more = JOptionPane.showConfirmDialog(null, "Add more Recipents?", null, JOptionPane.YES_NO_OPTION);
			if (more == JOptionPane.YES_OPTION) {
				more(recipients, username, password, path);
			}
			if (more == -1) {
				System.exit(1); // Exiting if window close
			}
		} else if (result == JOptionPane.CANCEL_OPTION) {
			// Confirm that the user want to send mail
			int send = JOptionPane.showConfirmDialog(null, "Send file by email?", null, JOptionPane.YES_NO_OPTION);
			if (send == JOptionPane.YES_OPTION) {
				askCredentials(recipients, username, password, path); // Restart procedure
			} else if (send == JOptionPane.NO_OPTION) {
				showFileCreatedDialog(path);
			} else {
				System.exit(1); // Exit if window close
			}
		} else {
			System.exit(1); // Exit if window close
		}

	}

	/**
	 * Display a window with a text area for implementing the recipients list
	 * 
	 * @param recipients List of recipients for the mailing
	 * @param username   Username for the case the user make a mistake
	 * @param password   Password for the case the user make a mistake
	 * @param path       Path of the Excel file for the case the user make a mistake
	 */
	private static void more(List<String> recipients, List<String> username, List<String> password, String path) {

		// Creating a JFrame for a JPanel with a layout of type springLayout
		JFrame frame = new JFrame();
		final SpringLayout layout = new SpringLayout();
		final JPanel panel = new JPanel(layout);
		panel.setPreferredSize(new Dimension(250, 160));

		// Adding a label and a textArea for the recipients to add
		JLabel lblSeparator = new JLabel("Separate mail address with \':\'");
		panel.add(lblSeparator);
		JTextArea txtRecipients = new JTextArea();
		txtRecipients.setBorder(BorderFactory.createLineBorder(Color.black));
		txtRecipients.setLineWrap(true);
		txtRecipients.setWrapStyleWord(true);
		JScrollPane scrollPane = new JScrollPane(txtRecipients); // Adding a scroll in case of a long list
		scrollPane.setPreferredSize(new Dimension(245, 130));
		panel.add(scrollPane);

		// Setting constraints for the layout
		layout.putConstraint(SpringLayout.WEST, lblSeparator, 0, SpringLayout.WEST, panel);
		layout.putConstraint(SpringLayout.WEST, txtRecipients, 25, SpringLayout.EAST, lblSeparator);
		layout.putConstraint(SpringLayout.NORTH, scrollPane, 10, SpringLayout.SOUTH, lblSeparator);

		// Adding recipients to the list
		int res = JOptionPane.showConfirmDialog(frame, panel, "Add recipients", JOptionPane.OK_CANCEL_OPTION,
				JOptionPane.PLAIN_MESSAGE);
		if (res == JOptionPane.YES_OPTION) {
			String[] address = txtRecipients.getText().split(":");
			recipients.addAll(Arrays.asList(address));
		} else if (res == JOptionPane.CANCEL_OPTION) {
			int option = JOptionPane.showConfirmDialog(null, "Exit procedure?", null, JOptionPane.YES_NO_OPTION);
			if (option == JOptionPane.NO_OPTION) { // Reinitializing lists and restart procedure
				recipients.removeAll(recipients);
				username.removeAll(username);
				password.removeAll(password);
				askCredentials(recipients, username, password, path);
			} else {
				System.exit(1); // Exit if window close
			}
		} else {
			System.exit(1); // Exit if window close
		}

	}

}