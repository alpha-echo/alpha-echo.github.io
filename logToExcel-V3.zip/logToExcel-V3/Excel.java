/*
 * File: Excel.java
 * Description: Class to create an Excel file from a LogEntry list
 * Author: Alpha_Echo
 */

package logToExcel;

import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xddf.usermodel.PresetColor;
import org.apache.poi.xddf.usermodel.XDDFColor;
import org.apache.poi.xddf.usermodel.XDDFLineProperties;
import org.apache.poi.xddf.usermodel.XDDFShapeProperties;
import org.apache.poi.xddf.usermodel.XDDFSolidFillProperties;
import org.apache.poi.xddf.usermodel.chart.AxisCrosses;
import org.apache.poi.xddf.usermodel.chart.AxisPosition;
import org.apache.poi.xddf.usermodel.chart.ChartTypes;
import org.apache.poi.xddf.usermodel.chart.LegendPosition;
import org.apache.poi.xddf.usermodel.chart.MarkerStyle;
import org.apache.poi.xddf.usermodel.chart.XDDFCategoryAxis;
import org.apache.poi.xddf.usermodel.chart.XDDFChartData;
import org.apache.poi.xddf.usermodel.chart.XDDFChartLegend;
import org.apache.poi.xddf.usermodel.chart.XDDFDataSource;
import org.apache.poi.xddf.usermodel.chart.XDDFDataSourcesFactory;
import org.apache.poi.xddf.usermodel.chart.XDDFLineChartData;
import org.apache.poi.xddf.usermodel.chart.XDDFNumericalDataSource;
import org.apache.poi.xddf.usermodel.chart.XDDFValueAxis;
import org.apache.poi.xssf.usermodel.DefaultIndexedColorMap;
import org.apache.poi.xssf.usermodel.XSSFChart;
import org.apache.poi.xssf.usermodel.XSSFClientAnchor;
import org.apache.poi.xssf.usermodel.XSSFDrawing;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.ss.util.CellRangeAddress;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTDLbls;


public class Excel {
	
	// Names of the headers columns
	private static final String[] COLUMN_HEADERS = { "Criticity", "Date", "Method", "Message", "Host", "File", "Line",
			"Occurrence" };

	/**
	 * Create an Excel file from a list of LogEntry
	 * 
	 * @param log        List of LogEntry
	 * @param path       Path of the Excel file to create
	 * @param display    Indicate if the file should be display to the user
	 * @throws IOException In case of Input/Output error when creating the Excel
	 *                     file
	 */

	public static void createExcelFile(List<List<LogEntry>> log, String path, boolean display)
			throws IOException {

		// Creation of excel sheet
		Workbook wb = new XSSFWorkbook();

		// Creation of the list for the most appeared method in the workbook
		String[] type = new String[log.size()];
		int[] num = new int[log.size()];

		// Create all the sheet with data and graphs
		sheetLog(log, wb, num, type);

		// Create the main sheet and put it in first and as active
		Sheet sheet = wb.createSheet("Graph");
		wb.setSheetOrder("Graph", 0);
		wb.setActiveSheet(0);

		// Create a list of String and fill it with the name of the other sheets
		String[] names = new String[wb.getNumberOfSheets() - 1];
		for (int i = 1; i < wb.getNumberOfSheets(); i++) {
			names[i - 1] = wb.getSheetName(i);
		}

		// Part the main graph

		// Create a drawing area and anchor it
		XSSFDrawing drawing = (XSSFDrawing) sheet.createDrawingPatriarch();
		XSSFClientAnchor anchor = drawing.createAnchor(0, 0, 0, 0, 0, 5, 20, 30);

		// Put a chart in the drawing area and add a title and a legend
		XSSFChart chart = drawing.createChart(anchor);
		chart.setTitleText("Occurrences over days");
		chart.setTitleOverlay(false);
		XDDFChartLegend legend = chart.getOrAddLegend();
		legend.setPosition(LegendPosition.TOP_RIGHT);

		// Use a category axis for the bottom axis.
		XDDFCategoryAxis bottomAxis = chart.createCategoryAxis(AxisPosition.BOTTOM);
		bottomAxis.setTitle("Days");
		XDDFValueAxis leftAxis = chart.createValueAxis(AxisPosition.LEFT);
		leftAxis.setTitle("Occurences");
		leftAxis.setCrosses(AxisCrosses.AUTO_ZERO);

		// Add the sources data for the graph
		XDDFDataSource<String> xs = XDDFDataSourcesFactory.fromArray(names);
		XDDFNumericalDataSource<Double> ys1 = XDDFDataSourcesFactory.fromArray(values(wb, 8));
		XDDFNumericalDataSource<Double> ys2 = XDDFDataSourcesFactory.fromArray(values(wb, 10));
		XDDFNumericalDataSource<Double> ys3 = XDDFDataSourcesFactory.fromArray(values(wb, 12));

		// Set the type of chart to line with two axis
		XDDFLineChartData data = (XDDFLineChartData) chart.createData(ChartTypes.LINE, bottomAxis, leftAxis);

		// Set the lines of the graphics with a title and a style for the legend

		XDDFLineChartData.Series series1 = (XDDFLineChartData.Series) data.addSeries(xs, ys1);
		series1.setTitle("Info", null);
		series1.setSmooth(false);
		series1.setMarkerStyle(MarkerStyle.STAR);

		XDDFLineChartData.Series series2 = (XDDFLineChartData.Series) data.addSeries(xs, ys2);
		series2.setTitle("Debug", null);
		series2.setSmooth(false);
		series2.setMarkerStyle(MarkerStyle.DOT);

		XDDFLineChartData.Series series3 = (XDDFLineChartData.Series) data.addSeries(xs, ys3);
		series3.setTitle("Warning", null);
		series3.setSmooth(false);
		series3.setMarkerStyle(MarkerStyle.DASH);

		// Create the chart
		chart.plot(data);

		// Do not auto delete the title; is necessary for showing title in LibreOffice
		// Calc
		if (chart.getCTChart().getAutoTitleDeleted() == null)
			chart.getCTChart().addNewAutoTitleDeleted();
		chart.getCTChart().getAutoTitleDeleted().setVal(false);

		// Set the colors of the lines
		solidLineSeries(data, 0, PresetColor.CHARTREUSE);
		solidLineSeries(data, 1, PresetColor.BLUE);
		solidLineSeries(data, 2, PresetColor.RED);
		
		
		// Part for the most appeared method

		// Create styles for the cells

		CellStyle styleA = wb.createCellStyle();
		Font font = wb.createFont();
		font.setBold(true);
		styleA.setFont(font);
		styleA.setBorderBottom(BorderStyle.THIN);
		styleA.setBottomBorderColor(IndexedColors.BLACK.getIndex());
		styleA.setBorderLeft(BorderStyle.THIN);
		styleA.setLeftBorderColor(IndexedColors.BLACK.getIndex());
		styleA.setBorderRight(BorderStyle.THIN);
		styleA.setRightBorderColor(IndexedColors.BLACK.getIndex());
		styleA.setBorderTop(BorderStyle.THIN);
		styleA.setTopBorderColor(IndexedColors.BLACK.getIndex());

		CellStyle styleB = wb.createCellStyle();
		styleB.setBorderBottom(BorderStyle.THIN);
		styleB.setBottomBorderColor(IndexedColors.BLACK.getIndex());
		styleB.setBorderLeft(BorderStyle.THIN);
		styleB.setLeftBorderColor(IndexedColors.BLACK.getIndex());
		styleB.setBorderRight(BorderStyle.THIN);
		styleB.setRightBorderColor(IndexedColors.BLACK.getIndex());
		styleB.setBorderTop(BorderStyle.THIN);
		styleB.setTopBorderColor(IndexedColors.BLACK.getIndex());

		// Create the row and cells
		Row row = sheet.createRow(6);
		Row row0 = sheet.createRow(5);
		Cell cellTxt = row0.createCell(21);
		cellTxt.setCellValue("Most encountered method");
		cellTxt.setCellStyle(styleA);
		sheet.setColumnWidth(21, 4100);
		sheet.addMergedRegion(new CellRangeAddress(5, 5, 21, 22));
		Cell cellType = row.createCell(21);
		Cell cellNum = row.createCell(22);

		// Get the most occurred method with it number
		int numMost = 0;
		int index = 0;
		for (int i = 0; i < num.length; i++) {
			if (num[i] > numMost) {
				numMost = num[i];
				index = i;
			}
		}
		String typeMost = type[index];

		// Fill the cells
		cellType.setCellValue(typeMost);
		cellType.setCellStyle(styleB);
		cellNum.setCellValue(numMost);
		cellNum.setCellStyle(styleB);
		
		// Creating xlsx file
		try (FileOutputStream outputStream = new FileOutputStream(path)) {
			wb.write(outputStream);
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				wb.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

	}

	/**
	 * Create a excel sheet for every list of LogEntry in logsByDay with the data
	 * from the list and a pie graph
	 * 
	 * @param logsByDay A list of list of LogEntry
	 * @param workbook  The workbook to work in
	 * @param num       list for the most encountered method in each list
	 * @param type      list for the type of the most encountered method in each
	 *                  list
	 */
	private static void sheetLog(List<List<LogEntry>> logsByDay, Workbook workbook, int[] num, String[] type) {
		int n = 0;
		for (List<LogEntry> logs : logsByDay) {
			n++;

			// Header
			Font headerFont = workbook.createFont();
			headerFont.setBold(true);
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
			Date dte = logs.get(0).getDate();
			String name = dateFormat.format(dte);
			Sheet sheet1 = workbook.createSheet(name);
			Row headerRow = sheet1.createRow(0);
			CellStyle headerCellStyle = workbook.createCellStyle();
			headerCellStyle.setAlignment(HorizontalAlignment.CENTER);
			headerCellStyle.setFont(headerFont);
			for (int i = 0; i < COLUMN_HEADERS.length; i++) {
				Cell cell = headerRow.createCell(i);
				cell.setCellValue(COLUMN_HEADERS[i]);
				cell.setCellStyle(headerCellStyle);
			}

			sheet1.addMergedRegion(new CellRangeAddress(0, 0, 7, 12));
			sheet1.setColumnWidth(3, 5000);
			sheet1.setColumnWidth(5, 5000);

			// Styles
			CellStyle styleB = workbook.createCellStyle();
			styleB.setBorderBottom(BorderStyle.THIN);
			styleB.setBottomBorderColor(IndexedColors.BLACK.getIndex());
			styleB.setBorderLeft(BorderStyle.THIN);
			styleB.setLeftBorderColor(IndexedColors.BLACK.getIndex());
			styleB.setBorderRight(BorderStyle.THIN);
			styleB.setRightBorderColor(IndexedColors.BLACK.getIndex());
			styleB.setBorderTop(BorderStyle.THIN);
			styleB.setTopBorderColor(IndexedColors.BLACK.getIndex());

			CellStyle style = workbook.createCellStyle();
			style.setWrapText(true);
			CellStyle dateStyle = workbook.createCellStyle();
			CreationHelper createHelper = workbook.getCreationHelper();
			short format = createHelper.createDataFormat().getFormat("dd/mm/yy hh:mm:ss:SSS");
			dateStyle.setDataFormat(format);

			int rowNum = 2;
			// HashMap for the method as string and the occurrence as integer
			Map<String, Integer> method = new HashMap<>();
			// Hash Map for the severity with the type as string and the occurrence as
			// integer
			Map<String, Integer> severity = new HashMap<>();

			for (LogEntry log : logs) {
				// Create the rows/cells and fill them
				Row row = sheet1.createRow(rowNum++);
				Cell cell1 = row.createCell(0);
				cell1.setCellValue(log.getSeverity());
				severity.put(log.getSeverity(), severity.getOrDefault(log.getSeverity(), 0) + 1);
				Cell cell2 = row.createCell(1);
				cell2.setCellStyle(dateStyle);
				cell2.setCellValue(log.getDate());
				Cell cell3 = row.createCell(2);
				cell3.setCellValue(log.getMethod());
				method.put(log.getMethod(), method.getOrDefault(log.getMethod(), 0) + 1);
				Cell cell4 = row.createCell(3);
				cell4.setCellValue(log.getMsg());
				Cell cell5 = row.createCell(4);
				cell5.setCellValue(log.getHost());
				Cell cell6 = row.createCell(5);
				cell6.setCellValue(log.getFile());
				Cell cell7 = row.createCell(6);
				cell7.setCellValue(log.getLine());

				// autoSize the column of the dates and get it size to use it as reference width
				sheet1.autoSizeColumn(1);
				int size = sheet1.getColumnWidth(1);
				for (int i = 2; i < 6; i++) {
					sheet1.setColumnWidth(i, size);
				}
			}

			// Create and fill the cells for the severity occurrence
			sheet1.createRow(1);
			int col = 7;
			for (Map.Entry<String, Integer> entry : severity.entrySet()) {
				Row row = sheet1.getRow(1);
				Cell cell8 = row.createCell(col);
				cell8.setCellStyle(styleB);
				cell8.setCellValue(entry.getKey());
				Cell cell9 = row.createCell(col + 1);
				cell9.setCellStyle(styleB);
				cell9.setCellValue(entry.getValue());
				col = col + 2;
			}

			// Same for the method occurrence
			int lastNum = 0;
			String lastType = null;
			int rowOffset = 4; // Start from row 4
			for (Map.Entry<String, Integer> entry : method.entrySet()) {
				if (entry.getValue() > lastNum) {
					lastNum = entry.getValue();
					lastType = entry.getKey();
				}
				Row row = sheet1.getRow(rowOffset);
				if (row == null) {
					row = sheet1.createRow(rowOffset);
				}
				Cell cell1 = row.createCell(7);
				cell1.setCellValue(entry.getKey());
				Cell cell2 = row.createCell(8);
				cell2.setCellValue(entry.getValue());
				rowOffset++;

			}

			// Set the Arrays for the main sheet
			type[n - 1] = lastType;
			num[n - 1] = lastNum;

			// Part for the Chart

			// Create a drawing area and anchor it
			XSSFDrawing drawing = (XSSFDrawing) sheet1.createDrawingPatriarch();
			XSSFClientAnchor anchor = drawing.createAnchor(0, 0, 0, 0, 5, 20, 20, 40);

			// Set a chart in the drawing area and set a title
			XSSFChart chart = drawing.createChart(anchor);
			chart.setTitleText("Percent of the method types");
			chart.setTitleOverlay(false);

			// Create a legend
			XDDFChartLegend legend = chart.getOrAddLegend();
			legend.setPosition(LegendPosition.TOP_RIGHT);

			// Set the data sources from cell of the sheet
			XDDFDataSource<String> categories = XDDFDataSourcesFactory.fromStringCellRange((XSSFSheet) sheet1,
					new CellRangeAddress(4, 4 + method.size() - 1, 7, 7));
			XDDFNumericalDataSource<Double> values = XDDFDataSourcesFactory.fromNumericCellRange((XSSFSheet) sheet1,
					new CellRangeAddress(4, 4 + method.size() - 1, 8, 8));

			// Create a chart of type pie
			XDDFChartData data = chart.createData(ChartTypes.PIE, null, null);
			data.setVaryColors(true);
			XDDFChartData.Series series = data.addSeries(categories, values);
			chart.plot(data);

			// Create the DLbls object if it doesn't exist
			if (!chart.getCTChart().getPlotArea().getPieChartArray(0).getSerArray(0).isSetDLbls()) {
				chart.getCTChart().getPlotArea().getPieChartArray(0).getSerArray(0).addNewDLbls();
			}

			CTDLbls dLbls = chart.getCTChart().getPlotArea().getPieChartArray(0).getSerArray(0).getDLbls();

			dLbls.addNewDLblPos().setVal(org.openxmlformats.schemas.drawingml.x2006.chart.STDLblPos.OUT_END);
			dLbls.addNewShowLegendKey().setVal(true);
			dLbls.addNewShowPercent().setVal(true);
			dLbls.addNewShowCatName().setVal(false);
			dLbls.addNewShowLeaderLines().setVal(false);
			dLbls.addNewShowVal().setVal(false);
			dLbls.addNewShowSerName().setVal(false);

			// Do not auto delete the title; is necessary for showing title in LibreOffice
			// Calc
			if (chart.getCTChart().getAutoTitleDeleted() == null)
				chart.getCTChart().addNewAutoTitleDeleted();
			chart.getCTChart().getAutoTitleDeleted().setVal(false);

			// Show the graphs for LibreOffice Calc
			int pointCount = series.getCategoryData().getPointCount();
			for (int p = 0; p < pointCount; p++) {
				chart.getCTChart().getPlotArea().getPieChartArray(0).getSerArray(0).addNewDPt().addNewIdx().setVal(p);
				chart.getCTChart().getPlotArea().getPieChartArray(0).getSerArray(0).getDPtArray(p).addNewSpPr()
						.addNewSolidFill().addNewSrgbClr().setVal(DefaultIndexedColorMap.getDefaultRGB(p + 10));
			}

			// Set workbook view properties for visibility in LibreOffice Calc
			workbook.setSheetVisibility(workbook.getSheetIndex(sheet1), SheetVisibility.VISIBLE);
			
		}
	}

	/**
	 * Function to return a list of values in the row 1 at the sheet num accross the
	 * sheets of a workbook (except for sheet#0
	 * 
	 * @param wb  The workbook to work in
	 * @param num Number of the column
	 * @return list of values in double type
	 */
	private static Double[] values(Workbook wb, int num) {
		Double[] vals = new Double[wb.getNumberOfSheets() - 1];
		for (int i = 1; i < wb.getNumberOfSheets(); i++) {
			XSSFSheet dataSheet = (XSSFSheet) wb.getSheetAt(i);
			XSSFRow row = dataSheet.getRow(1);
			Cell cell = row.getCell(num);
			if (cell != null) {
				vals[i - 1] = cell.getNumericCellValue();
			} else {
				vals[i - 1] = (double) 0;
			}
		}
		return vals;
	}

	/**
	 * Set the line properties for a chartData series with a given color
	 * 
	 * @param data  The chartData to work with
	 * @param index number of the series
	 * @param color the color to give to the line
	 */
	private static void solidLineSeries(XDDFChartData data, int index, PresetColor color) {
		XDDFSolidFillProperties fill = new XDDFSolidFillProperties(XDDFColor.from(color));
		XDDFLineProperties line = new XDDFLineProperties();
		line.setFillProperties(fill);
		XDDFChartData.Series series = data.getSeries(index);
		XDDFShapeProperties properties = series.getShapeProperties();
		if (properties == null) {
			properties = new XDDFShapeProperties();
		}
		properties.setLineProperties(line);
		series.setShapeProperties(properties);
	}

}