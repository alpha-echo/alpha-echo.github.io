/*
 * File: Excel.java
 * Description: Class to create an Excel file from a LogEntry list
 * Author: Alpha_Echo
 */

package logToExcel;

import java.awt.Color;
import java.awt.Desktop;
import java.awt.Dimension;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SpringLayout;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Excel {
	
	/**
	 * Create an Excel file from a list of LogEntry
	 * 
	 * @param log			List of LogEntry
	 * @param path			Path of the Excel file to create
	 * @param display		Indicate if the file should be display to the user
	 * @param originPath	Origin path of the log file
	 * @throws IOException	In case of Input/Output error when creating the Excel file
	 */

	public static void createExcelFile(List<LogEntry> log, String path, boolean display, String originPath) throws IOException {
		
		// Creation of excel sheet
		Workbook wb = new XSSFWorkbook();
		Sheet sheet = wb.createSheet("Logs");
		
		// Header
		Row headerRow = sheet.createRow(0);
		CellStyle cellStyle = wb.createCellStyle();
		cellStyle.setAlignment(HorizontalAlignment.CENTER);
		Cell headerCell1 = headerRow.createCell(0);
		headerCell1.setCellStyle(cellStyle);
		headerCell1.setCellValue("Criticité");
		Cell headerCell2 = headerRow.createCell(1);
		headerCell2.setCellStyle(cellStyle);
		headerCell2.setCellValue("Date");
		Cell headerCell3 = headerRow.createCell(2);
		headerCell3.setCellStyle(cellStyle);
		headerCell3.setCellValue("Message");
		Cell headerCell4 = headerRow.createCell(3);
		headerCell4.setCellStyle(cellStyle);
		headerCell4.setCellValue("Host");
		Cell headerCell5 = headerRow.createCell(4);
		headerCell5.setCellValue("Occurence");
		headerCell5.setCellStyle(cellStyle);
		
		//	Creation of styles
		sheet.setColumnWidth(2, 5000);
		CellStyle style = wb.createCellStyle();
		style.setWrapText(true);
		CellStyle dateStyle = wb.createCellStyle();
		CreationHelper createHelper = wb.getCreationHelper();
		short format = createHelper.createDataFormat().getFormat("dd/mm/yy hh:mm:ss:SSS");
		dateStyle.setDataFormat(format);
		
		// Get logs into excel
		int infos = 0; 
		int errors = 0; 
		int warnings = 0;
		int rowNum = 3;
		for (LogEntry logEntry : log) {
			Row row = sheet.createRow(rowNum++);
			Cell cell1 = row.createCell(0);
			cell1.setCellValue(logEntry.getSeverity());
			Cell cell2 = row.createCell(1);
			cell2.setCellStyle(style);
			cell2.setCellStyle(dateStyle);
			cell2.setCellValue(logEntry.getDate());
			Cell cell3 = row.createCell(2);
			cell3.setCellValue(logEntry.getMsg());
			Cell cell = row.createCell(3);
			cell.setCellValue(logEntry.getHost());
			Row row2 = sheet.createRow(1);
			Cell cell4 = row2.createCell(4);
			cell4.setCellValue("Error: "+logEntry.getOccurenceE());
			Cell cell5 = row2.createCell(5);
			cell5.setCellValue("Warning: "+logEntry.getOccurenceW());
			Cell cell6 = row2.createCell(6);
			cell6.setCellValue("Info: "+logEntry.getOccurenceI());
			infos = logEntry.getOccurenceI();
			errors = logEntry.getOccurenceE();
			warnings = logEntry.getOccurenceW();
		}
		
		//	Fuse cells for occurrence and resize rows
		sheet.addMergedRegion(new CellRangeAddress(0, 0, 4, 6));
		sheet.autoSizeColumn(0);
		sheet.autoSizeColumn(1);
		sheet.autoSizeColumn(3);
		sheet.autoSizeColumn(4);
		sheet.autoSizeColumn(5);
		sheet.autoSizeColumn(6);
				
		// Creating xlsx file
		try (FileOutputStream outputStream = new FileOutputStream(path)){
			wb.write(outputStream);
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				wb.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
		//	Display excel file or ask for username+password for email sending
		if (display) {
			showFileCreatedDialog(path);
		} else {
			List<String> recipients = new ArrayList<String>();
			List<String> username = new ArrayList<String>();
			List<String> password = new ArrayList<String>();
			askCredentials(recipients, username, password, path);
			SendMail.sendMail(errors, warnings, infos, originPath, recipients, username.get(0), password.get(0));
		}
	}

	/**
	 * Show a message dialogue informing of the creation of the Excel file and opening it if desktop environment supported
	 * 
	 * @param path	Path of the Excel file to create
	 */
	private static void showFileCreatedDialog(String path) {
		Path file = FileSystems.getDefault().getPath(path);
		String msg = "File " + file.getFileName() + " created";
		JOptionPane.showMessageDialog(null, msg);
		
		// Open File if Desktop supported
		if (Desktop.isDesktopSupported()) {
			Desktop desktop = Desktop.getDesktop();
			try {
				desktop.open(new File(path));
			} catch (IOException e) {
				e.printStackTrace();
			}
			System.exit(0); // Exit the program
		}
		
	}

	/**
	 * Display a window with 2 text filed and a password field and ask if more recipients should be added to the 
	 * recipients list
	 * 
	 * @param recipients	List of recipients for the mailing
	 * @param username		List of username for sending mail (a simple string didn't work)
	 * @param password		List of password for sending mail (a simple string didn't work)
	 * @param path			Path of the Excel file for the case the user make a mistake
	 */
	private static void askCredentials(List<String> recipients, List<String> username, List<String> password, String path) {
	
		// Create a JFrame for creating a JPanel with a SpringLayout
		JFrame frame = new JFrame();
		final SpringLayout layout = new SpringLayout();
		final JPanel panel = new JPanel(layout);
		panel.setPreferredSize(new Dimension(400, 100));

		// Creating label and textField
		JLabel lbl1 = new JLabel("Recipient:");
		JTextField textField1 = new JTextField(23);
		JLabel lbl2 = new JLabel("Your Username:");
		JTextField textField2 = new JTextField(23);
		JLabel lbl3 = new JLabel("Your Password:");
		JPasswordField passwordField = new JPasswordField(23);

		// Adding everything to the panel
		panel.add(lbl1);
		panel.add(textField1);
		panel.add(lbl2);
		panel.add(textField2);
		panel.add(lbl3);
		panel.add(passwordField);

		// Setting constraints for the layout
		layout.putConstraint(SpringLayout.WEST, lbl1, 10, SpringLayout.WEST, panel);
		layout.putConstraint(SpringLayout.NORTH, lbl1, 10, SpringLayout.NORTH, panel);
		layout.putConstraint(SpringLayout.WEST, textField1, 52, SpringLayout.EAST, lbl1);
		layout.putConstraint(SpringLayout.NORTH, textField1, 10, SpringLayout.NORTH, panel);
		layout.putConstraint(SpringLayout.WEST, lbl2, 10, SpringLayout.WEST, panel);
		layout.putConstraint(SpringLayout.NORTH, lbl2, 10, SpringLayout.SOUTH, textField1);
		layout.putConstraint(SpringLayout.WEST, textField2, 10, SpringLayout.EAST, lbl2);
		layout.putConstraint(SpringLayout.NORTH, textField2, 10, SpringLayout.SOUTH, textField1);
		layout.putConstraint(SpringLayout.WEST, lbl3, 10, SpringLayout.WEST, panel);
		layout.putConstraint(SpringLayout.NORTH, lbl3, 10, SpringLayout.SOUTH, textField2);
		layout.putConstraint(SpringLayout.WEST, passwordField, 12, SpringLayout.EAST, lbl3);
		layout.putConstraint(SpringLayout.NORTH, passwordField, 10, SpringLayout.SOUTH, textField2);

		// Adding what's inside fields to lists
		int result = JOptionPane.showConfirmDialog(frame, panel, "Enter required informations", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
		if (result == JOptionPane.YES_OPTION) {
			recipients.add(textField1.getText());
			username.add(textField2.getText());
			password.add(new String(passwordField.getPassword()));

			// JPanel to know if more recipients should be added
			int more = JOptionPane.showConfirmDialog(null, "Add more Recipents?", null, JOptionPane.YES_NO_OPTION);
			if (more == JOptionPane.YES_OPTION) {
				more(recipients, username, password, path);
			} if (more == -1) {
				System.exit(0); // Exiting if window close
			}
		} else if (result == JOptionPane.CANCEL_OPTION) {
			int send = JOptionPane.showConfirmDialog(null, "Send file by email?", null, JOptionPane.YES_NO_OPTION); // Confirm that the user want to send mail
			if (send == JOptionPane.YES_OPTION) {
				askCredentials(recipients, username, password, path); // Restart procedure
			} else if (send == JOptionPane.NO_OPTION) {
				showFileCreatedDialog(path);
			} else {
				System.exit(1); // Exit if window close 
			}
		} else {
			System.exit(1); // Exit if window close
		}

	}

	/**
	 * Display a window with a text area for implementing the recipients list
	 * 
	 * @param recipients	List of recipients for the mailing
	 * @param username		Username for the case the user make a mistake
	 * @param password		Password for the case the user make a mistake
	 * @param path			Path of the Excel file for the case the user make a mistake
	 */
	private static void more(List<String> recipients, List<String> username, List<String> password, String path) {
		
		// Creating a JFrame for a JPanel with a layout of type springLayout
		JFrame frame = new JFrame();
		final SpringLayout layout = new SpringLayout();  
		final JPanel panel = new JPanel(layout);
		panel.setPreferredSize(new Dimension(250, 160));

		// Adding a label and a textArea for the recipients to add
		JLabel lblSeparator = new JLabel("Separate mail address with \':\'");
		panel.add(lblSeparator);
		JTextArea txtRecipients = new JTextArea();
		txtRecipients.setBorder(BorderFactory.createLineBorder(Color.black));
		txtRecipients.setLineWrap(true);
		txtRecipients.setWrapStyleWord(true);
		JScrollPane scrollPane = new JScrollPane(txtRecipients); // Adding a scroll in case of a long list
		scrollPane.setPreferredSize(new Dimension(245, 130));
		panel.add(scrollPane);

		// Setting constraints for the layout
		layout.putConstraint(SpringLayout.WEST, lblSeparator, 0, SpringLayout.WEST, panel);
		layout.putConstraint(SpringLayout.WEST, txtRecipients, 25, SpringLayout.EAST, lblSeparator);
		layout.putConstraint(SpringLayout.NORTH, scrollPane, 10, SpringLayout.SOUTH, lblSeparator);

		// Adding recipients to the list
		int res = JOptionPane.showConfirmDialog(frame, panel, "Add recipients", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
		if (res == JOptionPane.YES_OPTION) {
			String[] address = txtRecipients.getText().split(":");
			recipients.addAll(Arrays.asList(address));
		} else if (res == JOptionPane.CANCEL_OPTION) {
			int option = JOptionPane.showConfirmDialog(null, "Exit procedure?", null, JOptionPane.YES_NO_OPTION);
			if (option == JOptionPane.NO_OPTION) { // Reinitializing lists and restart procedure
				recipients.remove(0);
				username.remove(0);
				password.remove(0);
				askCredentials(recipients, username, password, path);
			} else {
				System.exit(1); // Exit if window close
			}
		} else {
			System.exit(1); // Exit if window close
		}

	}

}