Adding a single window to ask the recipient/username/password and adding a
windows for the case of multiple recipients
