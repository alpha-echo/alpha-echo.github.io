/*
 * File: SendMail.java
 * Description: Class use for send e-mails
 * Author: Alpha_Echo
 */

package logToExcel;

import java.io.File;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Properties;
import java.util.Scanner;

import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.swing.JOptionPane;

public class SendMail {

	/**
	 * 
	 * @param numE			Numbers of errors
	 * @param numW			Numbers of warnings
	 * @param numI			Numbers of informations
	 * @param path			Path of the Excel file
	 * @param username		Username for the SMTP authentication
	 * @param password		Password for the SMTP authentication
	 * @throws IOException	In case of Input/Output error when getting the hostname or the Excel file
	 */

	public static void sendMail(int numE, int numW, int numI, String path, List<String> recipients, String username, String password) throws IOException {

		LocalDateTime myObj = LocalDateTime.now(); // Create a date object
		DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern("E dd/MM/yyyy HH:mm:ss");
		String date = myObj.format(myFormatObj);
		String from = username+"@dgfip.finances.gouv.fr";
		String host = "smtps-mes.appli.dgfip";
		String msg = "logToExcel have succed and found: "+numE+" errors, "+numW+" warnings and "+numI+" Infos in log file ("+hostname("hostname").subSequence(0, hostname("hostname").indexOf("\n"))+":"+path+")"+"\n\n"+date;

		// Adding mails address in recipients list to InternetAddress[]
		InternetAddress[] to = new InternetAddress[recipients.size()];
		for (int i = 0; i < recipients.size(); i++) {
			try {
				to[i] = new InternetAddress(recipients.get(i));
			} catch (AddressException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		//Get the session object  
		Properties properties = System.getProperties();
		properties.put("mail.smtp.host", host);
		properties.put("mail.smtp.auth", "true");
		properties.put("mail.smtp.port", "587");
		Session session = Session.getDefaultInstance(properties, new javax.mail.Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(username, password);
			}
		});
	
		//compose the message  
		try {
			MimeMessage message = new MimeMessage(session);
			message.setFrom(new InternetAddress(from));
			message.addRecipients(Message.RecipientType.TO, to);
			message.setSubject("logToExcel result file");

			//	Body of the message
			BodyPart messageBodyPart = new MimeBodyPart();
			messageBodyPart.setText(msg);

			//	Attachments
			MimeBodyPart attachementPart = new MimeBodyPart();
			attachementPart.attachFile(new File("logToExcel.xlsx"));

			//	Creation of the multipart content
			Multipart multipart = new MimeMultipart();
			multipart.addBodyPart(messageBodyPart);
			multipart.addBodyPart(attachementPart);

			//	Application of the multipart content
			message.setContent(multipart);

			// Send message
			Transport.send(message);

			//	Display a message to inform of sending
			String info = "Mail send succesfully";
			JOptionPane.showMessageDialog(null, info);

			//	Terminate the program
			System.exit(0);

		} catch (MessagingException mex) {
			mex.printStackTrace();
		}

	}
	
	/**
	 * Get the hostname of the local machine
	 * 
	 * @param hostname		Command to execute
	 * @return				Hostname of the local machine
	 * @throws IOException	In case of Input/Output error when executing the command
	 */
	public static String hostname(String hostname) throws IOException {
		try (Scanner s = new Scanner(Runtime.getRuntime().exec(hostname).getInputStream()).useDelimiter("\\A")) {
			return s.hasNext() ? s.next() : "";
		}
	}

}