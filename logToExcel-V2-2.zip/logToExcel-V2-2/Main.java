/*
 * File: Main.java
 * Description: Main class to test log conversion into Excel file
 * Author: Alpha_Echo
 */

package logToExcel;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileNameExtensionFilter;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Main {

	public static void main(String[] args) throws IOException {

		// Select log file
		JFileChooser fileChooser = new JFileChooser();
		fileChooser.setDialogTitle("Select log file");
		fileChooser.setFileFilter(new FileNameExtensionFilter("Log file:", "log", "out"));
		
		int userSelection = fileChooser.showOpenDialog(null);
		if (userSelection == JFileChooser.APPROVE_OPTION) {

			String path = fileChooser.getSelectedFile().getAbsolutePath();
			List<LogEntry> logs = new ArrayList<>();

			try (FileReader fileReader = new FileReader(path);
					BufferedReader reader = new BufferedReader(fileReader)) {
				String line = reader.readLine();
				int numE = 0;
				int numW = 1;
				int numI = 1;

				//	Read line of log and add it to LogEntry
				while (line != null) {

					String host = extractFromLog(line, "host\":\"", 12);
					String date = extractFromLog(line, "@timestamp\":\"", 24);
					
					if (line.contains("\"level\":\"INFO\"")) {
						logs.add(new LogEntry(line, "INFO", numI, numW, numE, host, date));
						numI++;
					} else if (line.contains("WARNING") || line.contains("WARN") || line.contains("\"level\":\"WARN\"")) {
						logs.add(new LogEntry(line, "Warning", numI, numW, numE, host, date));
						numW++;
					} else if (line.contains("ERROR") || line.contains("error")) {
						logs.add(new LogEntry(line, "Error", numI, numW, numE, host, date));
						numE++;
					}
					line = reader.readLine();
				}
 
			} catch (IOException e) {
				e.printStackTrace();
			}

			//	Comparing the severity between warning and information
			logs.sort(Comparator.comparing(LogEntry::getSeverity, (s1, s2) -> {
				if (s1.equals("Warning") && !s2.equals("Warning")) {
					return -1;
				} else if (!s1.equals("Warning") && s2.equals("Warning")) {
					return 1;
				} else {
					return 0;
				}
				
			}));

			// Generate Excel file and ask if it should be sent by mail
			String filePath = "logToExcel.xlsx";
			int reponse = JOptionPane.showConfirmDialog(null, "Send file by email?", null, JOptionPane.YES_NO_OPTION);
			if (reponse == 0) {
				Excel.createExcelFile(logs, filePath, false, path);
			} else if(reponse == 1){
				Excel.createExcelFile(logs, filePath, true, path);
			} else {
				System.exit(1); // Exit if window close
			}
		} else if (userSelection == JFileChooser.CANCEL_OPTION){
			System.exit(2);
		} else {
			System.exit(1); // Exit if window close
		}
		
	}

	/**
	 * Extract a part of a line log and return it
	 * 
	 * @param line		Line of log
	 * @param separator	Separator from when to start extracting
	 * @param count		Number of characters after the separator
	 * @return			The line of log with only the information wanted or a space character
	 */
	private static String extractFromLog(String line, String separator, int count) { 
		
		String reg = separator+".{"+count+"}";
		Pattern p = Pattern.compile(reg);
		Matcher m = p.matcher(line);
		if (m.find()) {
			line = m.group(0);
			line = line.substring(separator.length());
			return line;
		} else {
			return " ";
		}

	}

}