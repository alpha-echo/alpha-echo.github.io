/*
 * File: Excel.java
 * Description: Class to create an Excel file from a LogEntry list
 * Author: Alpha_Echo
 */

package logToExcel;

import java.awt.Desktop;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Path;
import java.util.List;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Excel {
	
	/**
	 * Create an Excel file from a list of LogEntry
	 * 
	 * @param log			List of LogEntry
	 * @param path			Path of the Excel file to create
	 * @param display		Indicate if the file should be display to the user
	 * @param originPath	Origin path of the log file
	 * @throws IOException	In case of Input/Output error when creating the Excel file
	 */

	public static void createExcelFile(List<LogEntry> log, String path, boolean display, String originPath) throws IOException {
		
		// Creation of excel sheet
		Workbook wb = new XSSFWorkbook();
		Sheet sheet = wb.createSheet("Logs");
		
		// Header
		Row headerRow = sheet.createRow(0);
		CellStyle cellStyle = wb.createCellStyle();
		cellStyle.setAlignment(HorizontalAlignment.CENTER);
		Cell headerCell1 = headerRow.createCell(0);
		headerCell1.setCellStyle(cellStyle);
		headerCell1.setCellValue("Criticité");
		Cell headerCell2 = headerRow.createCell(1);
		headerCell2.setCellStyle(cellStyle);
		headerCell2.setCellValue("Date");
		Cell headerCell3 = headerRow.createCell(2);
		headerCell3.setCellStyle(cellStyle);
		headerCell3.setCellValue("Message");
		Cell headerCell4 = headerRow.createCell(3);
		headerCell4.setCellStyle(cellStyle);
		headerCell4.setCellValue("Host");
		Cell headerCell5 = headerRow.createCell(4);
		headerCell5.setCellValue("Occurence");
		headerCell5.setCellStyle(cellStyle);
		
		//	Creation of styles
		sheet.setColumnWidth(2, 5000);
		CellStyle style = wb.createCellStyle();
		style.setWrapText(true);
		CellStyle dateStyle = wb.createCellStyle();
		CreationHelper createHelper = wb.getCreationHelper();
		short format = createHelper.createDataFormat().getFormat("dd/mm/yy hh:mm:ss:SSS");
		dateStyle.setDataFormat(format);
		
		// Get logs into excel
		int infos = 0; 
		int errors = 0; 
		int warnings = 0;
		int rowNum = 3;
		for (LogEntry logEntry : log) {
			Row row = sheet.createRow(rowNum++);
			Cell cell1 = row.createCell(0);
			cell1.setCellValue(logEntry.getSeverity());
			Cell cell2 = row.createCell(1);
			cell2.setCellStyle(style);
			cell2.setCellStyle(dateStyle);
			cell2.setCellValue(logEntry.getDate());
			Cell cell3 = row.createCell(2);
			cell3.setCellValue(logEntry.getMsg());
			Cell cell = row.createCell(3);
			cell.setCellValue(logEntry.getHost());
			Row row2 = sheet.createRow(1);
			Cell cell4 = row2.createCell(4);
			cell4.setCellValue("Error: "+logEntry.getOccurenceE());
			Cell cell5 = row2.createCell(5);
			cell5.setCellValue("Warning: "+logEntry.getOccurenceW());
			Cell cell6 = row2.createCell(6);
			cell6.setCellValue("Info: "+logEntry.getOccurenceI());
			infos = logEntry.getOccurenceI();
			errors = logEntry.getOccurenceE();
			warnings = logEntry.getOccurenceW();
		}
		
		//	Fuse cells for occurrence and size rows
		sheet.addMergedRegion(new CellRangeAddress(0, 0, 4, 6));
		sheet.autoSizeColumn(0);
		sheet.autoSizeColumn(1);
		sheet.autoSizeColumn(3);
		sheet.autoSizeColumn(4);
		sheet.autoSizeColumn(5);
		sheet.autoSizeColumn(6);
				
		// Creating xlsx file
		try (FileOutputStream outputStream = new FileOutputStream(path)){
			wb.write(outputStream);
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				wb.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
		//	Display excel file or ask for username+password for email sending
		if (display) {
			showFileCreatedDialog(path);
		} else {
			String username = JOptionPane.showInputDialog("Username of your email: ");
			String password = askCredentials();
			SendMail.sendMail(errors, warnings, infos, originPath, username, password);
		}
	}

	/**
	 * Display a password field for the email address
	 * 
	 * @return	The password field
	 */
	
	private static String askCredentials() {
		
		JPanel panel = new JPanel();
        final JPasswordField passwordField = new JPasswordField(20);
        panel.add(new JLabel("Enter your email password:"));
        panel.add(passwordField);
        JOptionPane pane = new JOptionPane(panel, JOptionPane.QUESTION_MESSAGE, JOptionPane.OK_CANCEL_OPTION) {
            private static final long serialVersionUID = 1L;
			@Override
            public void selectInitialValue() {
                passwordField.requestFocusInWindow();
            }
        };
        pane.createDialog(null, "Password Required").setVisible(true);
        return passwordField.getPassword().length == 0 ? null : new String(passwordField.getPassword());
	}

	/**
	 * Show a message dialogue informing of the creation of the Excel file and opening it if desktop environment supported
	 * 
	 * @param path	Path of the Excel file to create
	 */
	private static void showFileCreatedDialog(String path) {
		Path file = FileSystems.getDefault().getPath(path);
		String msg = "File " + file.getFileName() + " create";
		JOptionPane.showMessageDialog(null, msg);
		
		// Open File if Desktop supported
		if (Desktop.isDesktopSupported()) {
			Desktop desktop = Desktop.getDesktop();
			try {
				desktop.open(new File(path));
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
	}
	
}