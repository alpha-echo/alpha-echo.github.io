package logToExcel;

import java.awt.Desktop;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Path;
import java.util.List;

import javax.swing.JOptionPane;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Excel {

	public static void createExcelFile(List<LogEntry> log, String path) {
		// Creation of excel sheet
		Workbook wb = new XSSFWorkbook();
		Sheet sheet = wb.createSheet("Logs");
		
		// Header
		Row headerRow = sheet.createRow(0);
		CellStyle cellStyle = wb.createCellStyle();
		cellStyle.setAlignment(HorizontalAlignment.CENTER);
		Cell headerCell1 = headerRow.createCell(0);
		headerCell1.setCellStyle(cellStyle);
		headerCell1.setCellValue("Criticité");
		Cell headerCell2 = headerRow.createCell(1);
		headerCell2.setCellStyle(cellStyle);
		headerCell2.setCellValue("Date");
		Cell headerCell3 = headerRow.createCell(2);
		headerCell3.setCellStyle(cellStyle);
		headerCell3.setCellValue("Message");
		Cell headerCell4 = headerRow.createCell(3);
		headerCell4.setCellStyle(cellStyle);
		headerCell4.setCellValue("Host");
		Cell headerCell5 = headerRow.createCell(4);
		headerCell5.setCellValue("Occurence");
		headerCell5.setCellStyle(cellStyle);
		
		sheet.setColumnWidth(2, 5000);
		CellStyle style = wb.createCellStyle();
		style.setWrapText(true);
		CellStyle dateStyle = wb.createCellStyle();
		CreationHelper createHelper = wb.getCreationHelper();
		short format = createHelper.createDataFormat().getFormat("dd/mm/yy hh:mm:ss:SSS");
		dateStyle.setDataFormat(format);
		
		// Get logs into excel
		int num = 3;
		for (LogEntry logEntry : log) {
			Row row = sheet.createRow(num++);
			Cell cell1 = row.createCell(0);
			cell1.setCellValue(logEntry.getSeverity());
			Cell cell2 = row.createCell(1);
			cell2.setCellStyle(style);
			cell2.setCellStyle(dateStyle);
			cell2.setCellValue(logEntry.getDate());
			Cell cell3 = row.createCell(2);
			cell3.setCellValue(logEntry.getMsg());
			Cell cell = row.createCell(3);
			cell.setCellValue(logEntry.getHost());
			Row row2 = sheet.createRow(1);
			Cell cell4 = row2.createCell(4);
			cell4.setCellValue("Error: "+logEntry.getOccurenceE());
			Cell cell5 = row2.createCell(5);
			cell5.setCellValue("Warning: "+logEntry.getOccurenceW());
			
			Cell cell6 = row2.createCell(6);
			cell6.setCellValue("Info: "+logEntry.getOccurenceI());
		}
		
		sheet.addMergedRegion(new CellRangeAddress(0, 0, 4, 6));
		sheet.autoSizeColumn(0);
		sheet.autoSizeColumn(1);
		//sheet.autoSizeColumn(2);
		sheet.autoSizeColumn(3);
		sheet.autoSizeColumn(4);
		sheet.autoSizeColumn(5);
		sheet.autoSizeColumn(6);
				
		// Creating xlsx file
		try (FileOutputStream outputStream = new FileOutputStream(path)){
			wb.write(outputStream);
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				wb.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
		showFileCreatedDialog(path);
						
	}

	// Show Dialog with file
	private static void showFileCreatedDialog(String path) {
		Path file = FileSystems.getDefault().getPath(path);
		String msg = "File " + file.getFileName() + " create";
		JOptionPane.showMessageDialog(null, msg);
		
		// Open File if Desktop supported
		if (Desktop.isDesktopSupported()) {
			Desktop desktop = Desktop.getDesktop();
			try {
				desktop.open(new File(path));
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
	}
	
}
