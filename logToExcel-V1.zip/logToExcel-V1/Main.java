package logToExcel;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import javax.swing.JFileChooser;
import javax.swing.filechooser.FileNameExtensionFilter;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Main {

	public static void main(String[] args) {
		
		// Select log file
		JFileChooser fileChooser = new JFileChooser();
		fileChooser.setDialogTitle("Select log file");
		fileChooser.setFileFilter(new FileNameExtensionFilter("File log:", "log", "out"));
		
		int userSelection = fileChooser.showOpenDialog(null);
		if (userSelection == JFileChooser.APPROVE_OPTION) {
			String path = fileChooser.getSelectedFile().getAbsolutePath();
		
		
		List<LogEntry> logs = new ArrayList<>();
		
		try (FileReader fileReader = new FileReader(path);
			 BufferedReader reader = new BufferedReader(fileReader)) {
				 String line = reader.readLine();
				 int numE = 0;
				 int numW = 1;
				 int numI = 1;
				 
				 while (line != null) {
					 
					 String host = extractFromLog(line, "host\":\"", 12);
					 String date = extractFromLog(line, "@timestamp\":\"", 24);
					 
					 if (line.contains("\"level\":\"INFO\"")) {
						 logs.add(new LogEntry(line, "INFO", numI, numW, numE, host, date));
						 numI++;
					 } else if (line.contains("WARNING") || line.contains("WARN") || line.contains("\"level\":\"WARN\"")) {
						 logs.add(new LogEntry(line, "Warning", numI, numW, numE, host, date));
						 numW++;
					 } else if (line.contains("ERROR") || line.contains("error")) {
						 logs.add(new LogEntry(line, "Error", numI, numW, numE, host, date));
						 numE++;
					 }
					 line = reader.readLine();
				 }
				 
			 } catch (IOException e) {
				 e.printStackTrace();
			 }
			
			logs.sort(Comparator.comparing(LogEntry::getSeverity, (s1, s2) -> {
				if (s1.equals("Warning") && !s2.equals("Warning")) {
					return -1;
				} else if (!s1.equals("Warning") && s2.equals("Warning")) {
					return 1;
				} else {
					return 0;
				}
				
			}));
		
		
		// Generate Excel file
		String filePath = "fichier.xlsx";
		Excel.createExcelFile(logs, filePath);
		
		}
		
	}

	// Extract info from line of log
	private static String extractFromLog(String line, String separator, int count) { 
		
		String reg = separator+".{"+count+"}";
		Pattern p = Pattern.compile(reg);
		Matcher m = p.matcher(line);
		if (m.find()) {
			line = m.group(0);
			line = line.substring(separator.length());
			return line;
		} else {
			return " ";
		}

	}

}
