package logToExcel;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class LogEntry {

	public String msg;
	public String severity;
	public int occurenceI;
	public int occurenceE;
	public int occurenceW;
	public String host;
	public Date date;
	
	public LogEntry(String msg, String severity, int numI, int numW, int numE, String host, String date) {
		this.msg = msg;
		this.severity = severity;
		this.occurenceI = numI;
		this.occurenceW = numW;
		this.occurenceE = numE;
		this.host = host;
		SimpleDateFormat nDate = new SimpleDateFormat("yyyy-MM-DD'T'HH:mm:ss.SSS'Z'");
		try {
			this.date = nDate.parse(date);
		} catch (ParseException e) {
			e.printStackTrace();
		}
	}

	
	public String getMsg() {
		return msg;
	}
			
	public String getSeverity() {
		return severity;
	}
	
	public int getOccurenceI() {
		return occurenceI;
	}
	
	public int getOccurenceE() {
		return occurenceE;
	}
	
	public int getOccurenceW() {
		return occurenceW;
	}
		
	public String getHost() {
		return host;
	}
	
	public Date getDate() {
		return date;
	}
	
}
